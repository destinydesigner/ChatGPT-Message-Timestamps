# ChatGPT-Message-Timestamps
ChatGPT Message Timestamps — 在 ChatGPT 对话里显示每条消息的创建时间（本地/UTC、悬停精确到秒）
